<template>
  <div class="flex">
    <div class="w-1/6 px-4 py-8">
      <AppSideNavbar></AppSideNavbar>
    </div>
    <div class="w-5/6">
      <slot />
    </div>
  </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>