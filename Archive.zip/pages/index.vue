<template>
    <div class="pt-10 px-5">
        <div class="container mx-auto">
            <h1 class="text-4xl font-bold">Home</h1>
        </div>
    </div>
</template>

<script setup>

</script>